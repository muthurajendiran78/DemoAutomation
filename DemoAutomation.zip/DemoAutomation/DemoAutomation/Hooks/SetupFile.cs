﻿using DemoAutomation.ReusableFiles;
using OpenQA.Selenium;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace DemoAutomation.Hooks
{
    class SetupFile
    {
        public static string _status = "Pass";
        public static string _tcDescription = "";
        public static string _statusMessage = "Test case failed due to expected and actual differs";
        public static ExtentReports extent;
        public static ExtentTest test;
        public static IWebDriver driver = null;
        public static string basePath = "";

        [Binding]
        public class Setup
        {
            public static IWebDriver driver = null;
            [BeforeTestRun]
            public static void BeforeTestRun()
            {

                //InputDataFile InputDataFile = InputDataFilehelper.InputDataFile;

                basePath = CommonMethods.BasePath;
                string reportPath = basePath + @"\Reports\AutomationReport.html";
                extent = new ExtentReports(reportPath, true);
                extent.AddSystemInfo("hostname", "").AddSystemInfo("hostname", "").AddSystemInfo("hostname", "");
                extent.LoadConfig(basePath + @"\extent-config.xml");
            }
            [BeforeFeature]
            public static void BeforeFeature()
            {

            }
            [BeforeScenario]
            public static void BeforeScenario()
            {
                CommonMethods.LaunchBrowser();
                CommonMethods.ClearingCookies();
                var _tcDescription = ScenarioContext.Current.ScenarioInfo.Title;
                string name = _tcDescription.ToString();
                test = extent.StartTest(name);
                _status = "Pass";
            }
            [AfterFeature]
            public static void AfterFeature()
            {

            }
            [AfterScenario]
            public static void AfterScenario()
            {
                //POMFile.LoginPage.ClickUserDropDown();
                //bool status = CommonMethods.IsElementDisplayedByCSS("img.user-pic.img-circle");
                //if (status)
                //{
                //    LoginSteps.IClickedLogoutButton();
                //}

                if (_status == "Pass")
                {
                    test.Log(LogStatus.Pass, "Test case passed as expected and actual matches");
                }
                else
                {
                    test.Log(LogStatus.Fail, _statusMessage, test.AddScreenCapture(CommonMethods.CaptureScreenshotExtentReport()));
                }
                extent.EndTest(test);
                CommonMethods.CloseDriver();
            }
            [AfterTestRun]
            public static void AfterTestRun()
            {
                extent.Flush();
                extent.Close();
                //CommonMethods.EmailReport();
            }
        }

    }
}
