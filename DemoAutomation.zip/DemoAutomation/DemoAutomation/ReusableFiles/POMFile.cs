﻿using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAutomation.ReusableFiles
{
    class POMFile
    {
        //public static LoginPage LoginPage
        //{
        //    get
        //    {
        //        var commonPage = new LoginPage();
        //        PageFactory.InitElements(CommonMethods.driver, commonPage);
        //        return commonPage;
        //    }
        //}
    }
}
