﻿using DemoAutomation.Helpers;
using DemoAutomation.Hooks;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using MongoDB.Bson.IO;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace DemoAutomation.ReusableFiles
{
    class CommonMethods
    {

        //InputDataFile InputDataFile = InputDataFilehelper.InputDataFile;
        public static IWebDriver driver = null;
        //public static string BrowserDriverPath = ConfigurationManager.AppSettings["BrowserDriverPath"];
        public static string BrowserDriverPath = ConfigHelper.GetConfigValue("BrowserDriverPath");

        public static WebDriverWait wait;

        public static void LaunchBrowser()
        {
            WebDriver _webDriver = new WebDriver();
            driver = _webDriver.Current;
        }
        public static void LaunchGoogleChrome()
        {

            //var Browser = ConfigurationManager.AppSettings["Browser"];
            //BrowserDriverPath = CommonMethods.BasePath + BrowserDriverPath;
            try
            {
                var Browser = ConfigHelper.GetConfigValue("Browser");
                LogFile.LogErrorInformation("Going to launch" + Browser);
                switch (Browser.ToLower())
                {

                    case "ie":
                        InternetExplorerOptions op = new InternetExplorerOptions();
                        op.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        driver = new InternetExplorerDriver(BrowserDriverPath + "IEDriver", op);
                        break;
                    case "chrome":
                        ChromeOptions option = new ChromeOptions();
                        ChromeDriverService service = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service.SuppressInitialDiagnosticInformation = true;
                        option.AddArgument("--disable-extensions");
                        option.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option.AddUserProfilePreference("credentilas_enabled_service", false);
                        option.AddArgument("--start-maximized");
                        option.AddArgument("--allow-file-acces-from-file");
                        option.AddArgument("--disable-popup-blocking");
                        option.AddArgument("disable-infobars");
                        option.AddArgument("test-type");
                        option.AddUserProfilePreference("EnablePartialRendering", false);
                        driver = new ChromeDriver(service, option);
                        break;
                    case "phantomjsdriver":
                        //driver = new PhantomJSDriver(@"D:\DigitalSignUp\BDDSpecflowFrameworkSpecrunner\BDDSpecflowFrameworkSpecrunner\Drivers\PhantomJSDriver\");
                        break;
                    case "firefox":
                        //driver = new PhantomJSDriver(BrowserDriverPath + "PhantomJSDriver");
                        //DesiredCapabilities capability = DesiredCapabilities.Firefox();
                        //capability.SetCapability("platform", Platform.CurrentPlatform);
                        //capability.SetCapability("binary", "<C:\\Program Files\\Mozilla Firefox\\firefox.exe>");
                        break;

                }
            }
            catch (Exception e)
            {
                if (e.InnerException != null)
                {
                    string err = e.InnerException.Message;
                }
                throw;
            }

        }

        internal static void GetElementTextByXPath(IWebElement _takeClassName)
        {
            throw new NotImplementedException();
        }

        public static void GoToURL(string str)
        {
            driver.Navigate().GoToUrl(str);
            CommonMethods.WaitForPageToLoadComplete(2);
            LogFile.LogInformation("Application URL launched successfully");
        }

        public static void TypeValueInTextField(IWebElement element, string str)
        {
            try
            {
                //element.Clear();
                element.SendKeys(str);
                //string actualEnteredValue = GetElementAttributeValue(element, "value");
                //Assert.AreEqual(str, actualEnteredValue);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void TypeIntValueInTextField(IWebElement element, string value)
        {
            try
            {
                element.Clear();
                element.SendKeys(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void TypeValueInTextFieldByID(string id, string value)
        {
            try
            {
                //driver.FindElement(By.Id(id)).Clear();
                driver.FindElement(By.Id(id)).SendKeys(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void TypeValueInTextFieldByXPath(string xpath, string value)
        {
            try
            {
                driver.FindElement(By.XPath(xpath)).Clear();
                driver.FindElement(By.XPath(xpath)).SendKeys(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void TypeValueInTextFieldByName(string Name, string value)
        {
            try
            {
                driver.FindElement(By.Name(Name)).Clear();
                driver.FindElement(By.Name(Name)).SendKeys(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void TypeValueInTextFieldByCSS(string CssSelector, string value)
        {
            try
            {
                driver.FindElement(By.CssSelector(CssSelector)).Clear();
                driver.FindElement(By.CssSelector(CssSelector)).SendKeys(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void Click(IWebElement element)
        {
            try
            {
                element.Click();
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static string GetElementAttributeValue(IWebElement element, string value)
        {
            try
            {
                return element.GetAttribute(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }



        public static string GetElementAttributeValueByXPath(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.XPath(xpath)).GetAttribute(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static string GetElementAttributeValueByCSS(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.CssSelector(xpath)).GetAttribute(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetElementAttributeValueByID(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.Id(xpath)).GetAttribute(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void CloseDriver()
        {
            //driver.Close();
            driver.Quit();
        }
        public static string GetElementCSSValueByCSS(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.CssSelector(xpath)).GetCssValue(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetElementCSSValueByID(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.Id(xpath)).GetCssValue(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetElementCSSValueByXpath(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.XPath(xpath)).GetCssValue(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetElementCSSValueByLinkText(string xpath, string value)
        {
            try
            {
                return driver.FindElement(By.LinkText(xpath)).GetCssValue(value);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetElementText(IWebElement element)
        {
            try { return element.Text; }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }

        }
        public static string GetElementTextByXPath(string xpath)
        {
            try { return driver.FindElement(By.XPath(xpath)).Text; }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }

        }

        public static string GetElementTextByID(string id)
        {
            try { return driver.FindElement(By.Id(id)).Text; }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }

        }
        public static string GetElementTextByCSS(string CssSelector)
        {
            try { return driver.FindElement(By.CssSelector(CssSelector)).Text; }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }

        }
        public static string GetElementTextByLinkText(string LinkText)
        {
            try { return driver.FindElement(By.LinkText(LinkText)).Text; }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }

        }
        public static void ImplicitWait(int sec)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(sec);
        }

        public static void JavaScriptClick(IWebElement element)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                Thread.Sleep(1000);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                Thread.Sleep(1000);
                executor.ExecuteScript(hlJavaScript, element);
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", element);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptClickWindowClose(IWebElement element)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("window.close();", element);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        //public static void JavaScriptClickByXPath(string xpath)
        //{
        //    try
        //    {
        //        string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
        //        IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
        //        executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.XPath(xpath)) });
        //        executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.XPath(xpath)) });
        //    }
        //    catch (Exception e)
        //    {
        //        LogFile.LogInformation(e.ToString());
        //        CaptureScreenshot();
        //        SetupFile._status = "Fail";
        //        SetupFile._statusMessage = e.ToString();
        //        throw new Exception(e.ToString());
        //    }
        //}
        //public static void JavaScriptClickByID(string Id)
        //{
        //    try
        //    {
        //        IWebElement ele = driver.FindElement(By.Id(Id));
        //        IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
        //        executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
        //        string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
        //        //IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
        //        executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.Id(Id)) });
        //        executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.Id(Id)) });
        //    }
        //    catch (Exception e)
        //    {
        //        LogFile.LogInformation(e.ToString());
        //        CaptureScreenshot();
        //        SetupFile._status = "Fail";
        //        SetupFile._statusMessage = e.ToString();
        //        throw new Exception(e.ToString());
        //    }
        //}

        public static void JavaScriptClickByXPath(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                Thread.Sleep(1000);
                //string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                //Thread.Sleep(1000);
                //executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.XPath(xpath)) });
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.XPath(xpath)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JSClickByXPath(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                var script = String.Format("document.querySelector('{0}').style.display='inline-block';", ele);
                executor.ExecuteScript(script);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        //executeScript("var elem=arguments[0]; setTimeout(function() {elem.click();}, 100)", we);
        public static void JavaScriptClickByID(string id)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.Id(id));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                Thread.Sleep(1000);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                Thread.Sleep(1000);
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.Id(id)) });
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.Id(id)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptClickByCSS(string CssSelector)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.CssSelector(CssSelector));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                Thread.Sleep(1000);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                Thread.Sleep(1000);
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.CssSelector(CssSelector)) });
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.CssSelector(CssSelector)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptClickByLinkText(string LinkText)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.LinkText(LinkText));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                Thread.Sleep(1000);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                Thread.Sleep(1000);
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.LinkText(LinkText)) });
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.LinkText(LinkText)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptClickByName(string Name)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.Name(Name));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                Thread.Sleep(1000);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                Thread.Sleep(1000);
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.Name(Name)) });
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.Name(Name)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptImageUpload(string css, string path)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].setAttribute('style', arguments[1])", driver.FindElement(By.CssSelector(css)), "0");
            executor.ExecuteScript("arguments[0].setAttribute('class', arguments[1])", driver.FindElement(By.CssSelector(css)), "a");
            driver.FindElement(By.CssSelector(css)).SendKeys(path);
        }
        //public static void JavaScriptClickByCSS(string CssSelector)
        //{
        //    try
        //    {
        //        string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
        //        IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
        //        executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.CssSelector(CssSelector)) });
        //        executor.ExecuteScript("arguments[0].click();", new object[] { driver.FindElement(By.CssSelector(CssSelector)) });
        //    }
        //    catch (Exception e)
        //    {
        //        LogFile.LogInformation(e.ToString());
        //        CaptureScreenshot();
        //        SetupFile._status = "Fail";
        //        SetupFile._statusMessage = e.ToString();
        //        throw new Exception(e.ToString());
        //    }
        //}

        public static void ScrollToElementWithXpathRef(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void ScrollToElementWithIDRef(string id)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.Id(id));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void ScrollHorizontalRight(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.CssSelector("#CustomerList > div.pq-grid-center > div.pq-hscroll.pq-sb.pq-sb-horiz.pq-sb-horiz-t > div.pq-sb-slider.pq-sb-slider-h.ui-state-default.ui-corner-all.ui-draggable.ui-draggable-handle"));
                Actions move = new Actions(driver);
                move.MoveToElement(ele).ClickAndHold();
                move.MoveByOffset(125, 0);
                move.Release();
                move.Perform();
                //    IWebElement ele = driver.FindElement(By.Id(id));

                //    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                //    executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                IWebElement scroll = driver.FindElement(By.XPath("//*[@id='CustomerList']/div[2]/div[5]/div[2]"));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("window.scrollBy(2000,0)", scroll);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitForPageToLoadComplete(int min)
        {
            //driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(sec));
            try
            {
                IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromMinutes(min));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("return document.readyState").Equals("complete");
            }
            catch (Exception)
            {
                try
                {
                    IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromMinutes(min));
                    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                    executor.ExecuteScript("return document.readyState").Equals("complete");
                }
                catch (Exception)
                {
                    try
                    {
                        IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromMinutes(min));
                        IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                        executor.ExecuteScript("return document.readyState").Equals("complete");
                    }
                    catch (Exception)
                    {
                        try
                        {
                            IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromMinutes(min));
                            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                            executor.ExecuteScript("return document.readyState").Equals("complete");
                        }
                        catch (Exception e)
                        {
                            LogFile.LogInformation(e.ToString());
                            CaptureScreenshot();
                            SetupFile._status = "Fail";
                            SetupFile._statusMessage = e.ToString();
                            throw new Exception(e.ToString());
                        }
                    }
                }
            }
        }

        public static void ScrollToBottomOfPage()
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("window.scrollBy(0,1900)", "");
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void ScrollToTopOfPage()
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("scroll(0, -250);");
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static bool VerifyElementEditable(IWebElement ele1)
        {

            try
            {
                bool res;
                IWebElement ele = ele1;
                string tag = ele.TagName;

                if (tag == "div" | tag == "lable")

                    res = true;
                else
                    res = false;
                return res;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitUntilElemenetIsDisplayedByXpath(string xpath, int time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
                wait.Until(ExpectedConditions.ElementExists(By.XPath(xpath)));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void WaitForElementDisplayedByXpath(string xpath, int time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
                wait.Until(ExpectedConditions.ElementExists(By.XPath(xpath)));
            }
            catch (Exception e)
            {
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitUntilElemenetIsDisplayedByID(string id, int time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
                wait.Until(ExpectedConditions.ElementExists(By.Id(id)));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitUntilElemenetIsDisappearByCSS(string CssSelector, string text, int time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
                wait.Until(ExpectedConditions.InvisibilityOfElementWithText(By.CssSelector(CssSelector), text));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        //public static void WaitUntilElemenetIsDisplayed(IWebElement ele, int time)
        //{
        //    WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
        //    wait.Until(ele.Displayed);
        //}

        public static bool SearchForStringInPage(string str)
        {
            try
            {
                return driver.PageSource.Contains(str);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void SelectValueFromDropDown(IWebElement ele, string expValue)
        {
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void SelectValueFromDropDownWithoutCheck(IWebElement ele, string expValue)
        {
            try
            {
                var receivedValue = SelectValue(ele, expValue);
                LogFile.LogInformation(expValue + " has been selected in the dropdown");
            }

            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void SelectValueFromDropDownByID(string id, string expValue)
        {
            IWebElement ele = driver.FindElement(By.Id(id));
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueFromDropDownByCSS(string CssSelector, string expValue)
        {
            IWebElement ele = driver.FindElement(By.CssSelector(CssSelector));
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void DeSelectValueFromDropDownByID(string id, string value, string expValue)
        {
            IWebElement ele = driver.FindElement(By.Id(id));
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = DeSelectValueByText(ele, value);
                Thread.Sleep(1000);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = DeSelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueFromDropDownByCSSToUpperCase(string CssSelector, string expValue)
        {
            expValue = "Value2";
            IWebElement ele = driver.FindElement(By.CssSelector(CssSelector));
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                expValue = expValue.ToUpper();
                if (receivedValue != expValue)
                {
                    if (receivedValue.Contains(expValue))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue != expValue)
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueFromDropDownByName(string Name, string expValue)
        {
            //SelectElement TimeZoneSelect = new SelectElement(driver.FindElement(By.Name(Name)));
            //IList<IWebElement> ElementCount = TimeZoneSelect.Options;
            //int ItemSize = ElementCount.Count;
            //LogFile.LogInformation("ItemSize:"+ ItemSize);
            //for (int i = 0; i < ItemSize; i++)
            //{
            //    String ItemValue = ElementCount.ElementAt(i).Text;
            //    LogFile.LogInformation(ItemValue);
            //}
            IWebElement ele = driver.FindElement(By.Name(Name));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void rightclick(IWebElement element)
        {
            try
            {
                var action = new Actions(driver);
                Thread.Sleep(2000);
                action.ContextClick(element).Build().Perform();
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static bool DynamicElement(string elementXPath)
        {
            string key = string.Empty;
            try
            {
                if (!string.IsNullOrWhiteSpace(elementXPath))
                {
                    var items = CommonMethods.driver.FindElements(By.XPath(elementXPath));
                    int count = items != null ? items.Count() : 0;
                    if (count > 0)
                    {
                        for (int index = 1; index <= count; index++)
                        {
                            string xpath = elementXPath + "[" + index + "]";
                            bool lastyearenable = CommonMethods.IsElementDisplayedByXpath(xpath);
                            if (lastyearenable)
                            {
                                key = xpath;

                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return true;
        }
        public static void launchExtranetUrl(string extranetUrl)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("window.open('" + extranetUrl + "')");
                Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string Value(IWebElement element, string value)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                value = executor.ExecuteScript("return arguments[0].value", element) as string;
                return value;
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void launchUrlInNewTabWindow(string Url)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("window.open('" + Url + "')");
                Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueFromDropDownByXPath(string xpath, string expValue)
        {
            //SelectElement TimeZoneSelect = new SelectElement(driver.FindElement(By.Name(Name)));
            //IList<IWebElement> ElementCount = TimeZoneSelect.Options;
            //int ItemSize = ElementCount.Count;
            //LogFile.LogInformation("ItemSize:"+ ItemSize);
            //for (int i = 0; i < ItemSize; i++)
            //{
            //    String ItemValue = ElementCount.ElementAt(i).Text;
            //    LogFile.LogInformation(ItemValue);
            //}
            IWebElement ele = driver.FindElement(By.XPath(xpath));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValue(ele, expValue);
                if (receivedValue.ToUpper() != expValue.ToUpper())
                {
                    if (receivedValue.ToUpper().Contains(expValue.ToUpper()))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue.ToUpper() != expValue.ToUpper())
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void SelectValueFromByIndex(string name, int index, string expValue)
        {
            //SelectElement TimeZoneSelect = new SelectElement(driver.FindElement(By.Name(Name)));
            //IList<IWebElement> ElementCount = TimeZoneSelect.Options;
            //int ItemSize = ElementCount.Count;
            //LogFile.LogInformation("ItemSize:"+ ItemSize);
            //for (int i = 0; i < ItemSize; i++)
            //{
            //    String ItemValue = ElementCount.ElementAt(i).Text;
            //    LogFile.LogInformation(ItemValue);
            //}
            IWebElement ele = driver.FindElement(By.Name(name));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                if (expValue == null)
                {
                    return;
                }
                var receivedValue = SelectValueByIndex(ele, index);
                Thread.Sleep(1000);
                if (receivedValue != expValue)
                {
                    if (receivedValue.Contains(expValue))
                    {
                        return;
                    }
                    receivedValue = SelectValue(ele, expValue);
                    if (receivedValue != expValue)
                    {
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = "Seleced elemetn is not as expected" + receivedValue;
                        throw new Exception("Seleced elemetn is not as expected" + receivedValue);
                    }
                }
                else
                {
                    LogFile.LogInformation(expValue + " has been selected in the dropdown");
                }
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueByIndex(string name, int index)
        {
            IWebElement ele = driver.FindElement(By.Name(name));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                SelectValueByIndex(ele, index);
                Thread.Sleep(1000);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SelectValueFromDropDownByID1(string id, string expValue)
        {
            IWebElement ele = driver.FindElement(By.Id(id));
            try
            {
                if (expValue == null)
                {
                    return;
                }
                SelectValue(ele, expValue);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string SelectValue(IWebElement ele, string expValue)
        {
            var selectedElement = new SelectElement(ele);
            try
            {
                selectedElement.SelectByText(expValue);
            }
            catch (Exception)
            {
                var allItems = selectedElement.Options;
                if (allItems.Count == 0)
                    throw new Exception("There are no options availale");
                foreach (var item in allItems.Where(item => item.Text.Contains(expValue)))
                {
                    try
                    {
                        selectedElement.SelectByText(item.Text);
                    }
                    catch (Exception e)
                    {
                        CommonMethods.CaptureScreenshot();
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = e.ToString();
                        throw new Exception(e.ToString());
                    }
                    return item.Text;
                }
            }
            return selectedElement.SelectedOption.Text;
        }
        public static string GetSelectedValueFromDropdownByID(string id)
        {
            IWebElement ele = driver.FindElement(By.Id(id));
            var selectedElement = new SelectElement(ele);
            return selectedElement.SelectedOption.Text;
        }
        public static string GetSelectedValueFromDropdownByName(string Name)
        {
            IWebElement ele = driver.FindElement(By.Name(Name));
            var selectedElement = new SelectElement(ele);
            return selectedElement.SelectedOption.Text;
        }
        public static string DeSelectValue(IWebElement ele, string expValue)
        {
            var selectedElement = new SelectElement(ele);
            try
            {
                selectedElement.DeselectAll();
            }
            catch (Exception)
            {

            }
            return selectedElement.SelectedOption.Text;
        }
        public static string DeSelectValueByText(IWebElement ele, string expValue)
        {
            var selectedElement = new SelectElement(ele);
            try
            {
                selectedElement.DeselectByValue(expValue);
            }
            catch (Exception)
            {

            }
            return selectedElement.SelectedOption.Text;
        }
        public static string SelectValueByIndex(IWebElement ele, int expValue)
        {
            var selectedElement = new SelectElement(ele);
            try
            {
                selectedElement.SelectByIndex(expValue);
            }
            catch (Exception)
            {
                var allItems = selectedElement.Options;
                if (allItems.Count == 0)
                    throw new Exception("There are no options availale");
                foreach (var item in allItems.Where(item => item.Text.Contains(selectedElement.Options.ToString())))
                {
                    try
                    {
                        selectedElement.SelectByText(item.Text);
                    }
                    catch (Exception e)
                    {
                        CommonMethods.CaptureScreenshot();
                        SetupFile._status = "Fail";
                        SetupFile._statusMessage = e.ToString();
                        throw new Exception(e.ToString());
                    }
                    return item.Text;
                }
            }
            return selectedElement.SelectedOption.Text;
        }
        public static string GetSelectedValueFromDropDown(IWebElement ele)
        {
            string receivedValue;
            var selectedEle = new SelectElement(ele);
            try
            {
                receivedValue = selectedEle.SelectedOption.Text;
                return receivedValue;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetSelectedValueFromDropDownByXpath(string xpath)
        {
            string receivedValue;
            var selectedEle = new SelectElement(driver.FindElement(By.XPath(xpath)));
            try
            {
                receivedValue = selectedEle.SelectedOption.Text;
                return receivedValue;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static bool IsCheckBoxSelected(IWebElement ele)
        {
            try
            {

                if (!ele.Displayed) { return false; }
                if (!ele.Enabled) { return false; }
                return ele.Selected;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static bool IsCheckBoxSelectedbyXpath(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                if (!ele.Displayed) { return false; }
                if (!ele.Enabled) { return false; }

                return ele.Selected;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static bool IsCheckBoxSelectedbyID(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.Id(xpath));
                if (!ele.Enabled) { return false; }
                return ele.Selected;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void WaitUntilURLContains(string str)
        {
            try
            {
                wait.Until(driver => GetUrl.Contains(str));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void WaitUntilElementsEnabled(IWebElement ele)
        {
            try
            {
                wait.Until(driver => ele.Enabled);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitUntilElementsEnabledByXpath(string xpath)
        {
            try
            {
                wait.Until(driver => driver.FindElement(By.XPath(xpath)).Enabled);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }


        public static void WaitUntilElementsDisplayed(IWebElement ele)
        {
            try
            {
                wait.Until(driver => ele.Displayed);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void WaitUntilElementsDisplayedXpath(string str)
        {
            try
            {
                wait.Until(driver => driver.FindElements(By.XPath(str)));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static bool IsElementDisplayed(IWebElement ele)
        {
            bool actres;
            try
            {

                actres = ele.Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }

        public static bool IsElementDisplayedByXpath(string xpath)
        {
            bool actres;
            try
            {

                actres = driver.FindElement(By.XPath(xpath)).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }
        public static bool IsElementDisplayedByLink(string xpath)
        {
            bool actres;
            try
            {

                actres = driver.FindElement(By.LinkText(xpath)).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }
        public static bool IsElementDisplayedByID(string id)
        {
            bool actres;
            try
            {

                actres = driver.FindElement(By.Id(id)).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }
        public static bool IsElementDisplayedByCSS(string css)
        {
            bool actres;
            try
            {

                actres = driver.FindElement(By.CssSelector(css)).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }
        public static bool IsElementDisplayedByName(string Name)
        {
            bool actres;
            try
            {

                actres = driver.FindElement(By.Name(Name)).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
            return actres;
        }
        public static void DragDrop(IWebElement ele1, IWebElement ele2)
        {
            try
            {
                WaitUntilElementsEnabled(ele1);
                WaitUntilElementsEnabled(ele2);
                var bui = new Actions(driver);
                var DragDrop = bui.ClickAndHold(ele1).MoveToElement(ele2).Release(ele2).Build();
                DragDrop.Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void PageRefresh(IWebElement ele)
        {
            try
            {
                var action = new Actions(driver);
                action.SendKeys(OpenQA.Selenium.Keys.F5).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static IReadOnlyCollection<IWebElement> FindElementsByXpath(string xpath)
        {
            try
            {
                return driver.FindElements(By.XPath(xpath));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }


        public static void CaptureScreenshot1()
        {
            //// ((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.zoom = '60%';");
            string basePath = CommonMethods.BasePath;
            string path = basePath + @"\Screenshots\output";
            var cantakescreenshot = (driver as ITakesScreenshot) != null;
            if (!cantakescreenshot)
                return;
            var filename = string.Empty + DateTime.Now.ToString("ddmmyyyyHHmmss");
            filename = path + @"\" + filename + ".bmp";
            var ss = ((ITakesScreenshot)driver).GetScreenshot();
            var screenshot = ss.AsBase64EncodedString;
            byte[] screenshotAsByteArray = ss.AsByteArray;
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            ss.SaveAsFile(filename, ScreenshotImageFormat.Bmp);
            var ssFilePath = Path.Combine(path, filename);
            Console.WriteLine(@"Screenshot: {0}", new Uri(ssFilePath));
        }

        public static void SwitchToNewWindow()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwitchToNewWindowNoBrowserClose()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);

                //driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static string BasePath
        {
            get
            {
                var basePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

                return basePath;
            }
        }

        public static IList<IWebElement> collectionsByXpath(string value)
        {
            try
            {
                IList<IWebElement> elements = null;
                return elements = driver.FindElements(By.XPath(value));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void SwitchToDefaultContent()
        {
            try
            {
                driver.SwitchTo().DefaultContent();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void MouseHover(IWebElement ele)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                var action = new Actions(driver);
                action.MoveToElement(ele).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverByID(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.Id(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverByCSS(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.CssSelector(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverByLinkText(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.LinkText(ele));
                //IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                //Thread.Sleep(1000);
                //executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverByXPath(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                //Thread.Sleep(1000);
                //executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverClickByXPath(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).Click().Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void MouseHoverClickAndHoldByXPath(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).ClickAndHold().Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void DoubleClick(IWebElement ele)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                var action = new Actions(driver);
                action.DoubleClick(ele).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void DoubleClickByCSS(string CssSelector)
        {
            IWebElement ele = driver.FindElement(By.CssSelector(CssSelector));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                var action = new Actions(driver);
                action.DoubleClick(ele).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void DoubleClickByXpath(string XPath)
        {
            IWebElement ele = driver.FindElement(By.XPath(XPath));
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
            try
            {
                var action = new Actions(driver);
                action.DoubleClick(ele).Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetUrl
        {
            get { return driver.Url; }
        }

        public static void ExplicitWait(int sec)
        {
            IWait<IWebDriver> wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromSeconds(sec));
        }

        public static string GetScreenShotPath()
        {
            return ConfigurationManager.AppSettings["Browser"];
        }

        public static string GetEnvironment()
        {
            return ConfigurationManager.AppSettings["Environment"];
        }

        public static void ClickByXPath(string xpath)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", new object[] { driver.FindElement(By.XPath(xpath)) });
            driver.FindElement(By.XPath(xpath)).Click();
        }
        public static void ClickByName(string name)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", new object[] { driver.FindElement(By.Name(name)) });
            driver.FindElement(By.Name(name)).Click();
        }
        public static void ClickByCSS(string CssSelector)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", new object[] { driver.FindElement(By.CssSelector(CssSelector)) });
            driver.FindElement(By.CssSelector(CssSelector)).Click();
        }
        public static void ClickByID(string Id)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Thread.Sleep(1000);
            executor.ExecuteScript("arguments[0].scrollIntoView(true);", new object[] { driver.FindElement(By.Id(Id)) });
            driver.FindElement(By.Id(Id)).Click();
        }
        public static void ClickByLinkText(string xpath)
        {
            driver.FindElement(By.LinkText(xpath)).Click();
        }
        //public static void ClickEnterButton()
        //{
        //    Thread.Sleep(1000);
        //    SendKeys.SendWait("{ENTER}");
        //    Thread.Sleep(1000);
        //    LogFile.LogInformation("Clicked on Enter button");
        //}

        public static void ExcelClose()
        {
            //System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("Excel");
            System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("wps");
            foreach (System.Diagnostics.Process p in process)
            {
                if (!string.IsNullOrEmpty(p.ProcessName))
                {
                    try
                    {
                        p.Kill();
                    }
                    catch { }
                }
            }
        }
        public static void ClearingCookies()
        {
            var _cookies = driver.Manage().Cookies.AllCookies;
            foreach (OpenQA.Selenium.Cookie cookie in _cookies)
            {
                driver.Manage().Cookies.AddCookie(cookie);
            }
            var _newCookies = driver.Manage().Cookies.AllCookies;
        }

        public static void todaysdate(IWebElement element)
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void Date(IWebElement element)
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                //LogFile.LogInformation(todaysDate.ToString("MM/dd/yyyy"));
                int day = todaysDate.Day;
                System.Diagnostics.Debug.WriteLine(day);
                if (day >= 1 && day <= 20)
                {
                    // todaysDate.AddDays(5);
                    String datestring = todaysDate.AddDays(5).ToString("MM/dd/yyyy");
                    //datestring.AddDays(5);
                    element.Clear();
                    element.SendKeys(datestring);
                }
                else
                {
                    var tempDate = todaysDate.AddMonths(1);
                    var newDate = new DateTime(tempDate.Year, tempDate.Month, 1);
                    String datestring = newDate.ToString("MM/dd/yyyy");
                    element.Clear();
                    element.SendKeys(datestring);
                }

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void TypeCurrentdate(IWebElement element)
        {
            try
            {
                DateTime todaysDate = DateTime.Today;
                String datestring = DateTime.Now.ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);
                element.SendKeys(OpenQA.Selenium.Keys.Tab);
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static void EmailReport()
        {
            try
            {
                string EmailFrom = ConfigurationManager.AppSettings["EmailFrom"];
                string Password = ConfigurationManager.AppSettings["Password"];
                string MailRecepient1 = ConfigurationManager.AppSettings["MailRecipient1"];
                string MailRecepient2 = ConfigurationManager.AppSettings["MailRecipient2"];
                string MailRecepient3 = ConfigurationManager.AppSettings["MailRecipient3"];
                string MailRecepient4 = ConfigurationManager.AppSettings["MailRecipient4"];
                string MailRecepient5 = ConfigurationManager.AppSettings["MailRecipient5"];
                string BasePath = CommonMethods.BasePath;
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.office365.com");
                mail.From = new MailAddress(EmailFrom);
                if (MailRecepient1 == null || MailRecepient1 == "")
                {
                    LogFile.LogInformation("Mail Recepient is null");
                }
                else
                {
                    mail.To.Add(MailRecepient1);
                }
                if (MailRecepient2 == null || MailRecepient2 == "")
                {
                    LogFile.LogInformation("Mail Recepient is null");
                }
                else
                {
                    mail.To.Add(MailRecepient2);
                }
                if (MailRecepient3 == null || MailRecepient3 == "")
                {
                    LogFile.LogInformation("Mail Recepient is null");
                }
                else
                {
                    mail.To.Add(MailRecepient3);
                }
                if (MailRecepient4 == null || MailRecepient4 == "")
                {
                    LogFile.LogInformation("Mail Recepient is null");
                }
                else
                {
                    mail.To.Add(MailRecepient4);
                }
                if (MailRecepient5 == null || MailRecepient5 == "")
                {
                    LogFile.LogInformation("Mail Recepient is null");
                }
                else
                {
                    mail.To.Add(MailRecepient5);
                }

                mail.Subject = "Komtrax DB Portal Automation Report";
                mail.Body = "Automation Execution completed. Please find the attched report. This is Auto generated mail, failures in this mail are not analysed";

                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(BasePath + @"\Reports\AutomationReport.html");
                mail.Attachments.Add(attachment);

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential(EmailFrom, Password);
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                LogFile.LogInformation("Mail Sent successfully");
            }
            catch (Exception ex)
            {
                LogFile.LogInformation(ex.ToString());
            }
        }
        public static IList<IWebElement> collectionsByID(string value)
        {
            try
            {
                IList<IWebElement> elements = null;
                return elements = driver.FindElements(By.Id(value));
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static string CaptureScreenshotExtentReport()
        {
            string basePath = CommonMethods.BasePath;
            string path = basePath + @"\Screenshots\output";
            var cantakescreenshot = (driver as ITakesScreenshot) != null;
            if (!cantakescreenshot)
                return null;
            var filename = string.Empty + DateTime.Now.ToString("ddmmyyyyHHmmss");
            filename = path + @"\" + filename + ".png";
            var ss = ((ITakesScreenshot)driver).GetScreenshot();
            var screenshot = ss.AsBase64EncodedString;
            byte[] screenshotAsByteArray = ss.AsByteArray;
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            ss.SaveAsFile(filename, ScreenshotImageFormat.Png);
            var ssFilePath = Path.Combine(path, filename);
            Console.WriteLine(@"Screenshot: {0}", new Uri(ssFilePath));
            return ssFilePath;
        }

        public static void MultipleWindows()
        {
            // Store the parent window of the driver
            String parentWindowHandle = driver.CurrentWindowHandle;
            Console.WriteLine("Parent window's handle -> " + parentWindowHandle);

            // Store all the opened window into the 'list' 
            List<string> lstWindow = driver.WindowHandles.ToList();

            // Traverse each and every window 
            foreach (var handle in lstWindow)
            {
                driver.SwitchTo().Window(handle);
            }

        }

        public static void SpecrunClose()
        {
            System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("specrun.exe");
            foreach (System.Diagnostics.Process p in process)
            {
                if (!string.IsNullOrEmpty(p.ProcessName))
                {
                    try
                    {
                        p.Kill();
                    }
                    catch { }
                }
            }
        }

        public static void WaitUntilLoadingBarToDisappearByCSS(string CssSelector, double Time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.CssSelector(CssSelector)));
            }
            catch (Exception e)
            {

            }

        }
        public static void WaitUntilLoadingBarToDisappearByXpath(string XPath, double Time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath(XPath)));
            }
            catch (Exception e)
            {

            }

        }
        public static void WaitUntilLoadingBarToDisappearByID(string ID, double Time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.Id(ID)));
            }
            catch (Exception e)
            {

            }

        }

        public static void WaitUntilElementToDisplayyByID(string ID, double Time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
                wait.Until(ExpectedConditions.ElementIsVisible(By.Id(ID)));
            }
            catch (Exception e)
            {

            }

        }
        public static void WaitUntilElementToDisplayyByCSS(string CssSelector, double Time)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
                wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector(CssSelector)));
            }
            catch (Exception e)
            {

            }

        }
        public static void ReplaceNodeValueInXmlFile(string filePath, string node, string value)
        {
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(filePath);
            xDoc.SelectSingleNode(node).InnerText = value;
            xDoc.Save(filePath);
        }
        public static string UploadFileUsingFTP(string FtpUrl, string fileName, string userName, string password, string UploadDirectory = "")
        {
            string PureFileName = new FileInfo(fileName).Name;
            String uploadUrl = String.Format("{0}{1}/{2}", FtpUrl, UploadDirectory, PureFileName);
            FtpWebRequest req = (FtpWebRequest)FtpWebRequest.Create(uploadUrl);
            req.Proxy = null;
            req.Method = WebRequestMethods.Ftp.UploadFile;
            req.Credentials = new NetworkCredential(userName, password);
            req.UseBinary = true;
            req.UsePassive = true;
            byte[] data = File.ReadAllBytes(fileName);
            req.ContentLength = data.Length;
            Stream stream = req.GetRequestStream();
            stream.Write(data, 0, data.Length);
            stream.Close();
            FtpWebResponse res = (FtpWebResponse)req.GetResponse();
            return res.StatusDescription;
        }

        public static string GetRandomEmail()
        {
            Random _random = new Random();
            return string.Format("AutomationTesting{0}@test.com", _random.Next(10000, 99999));
        }
        public static string GetRandomName()
        {
            Random _random = new Random();
            return string.Format("AutomationGroup{0}", _random.Next(10000, 99999));
        }
        public static int GetRandomNumber()
        {
            Random _random = new Random();
            return _random.Next(10000, 99999);
        }
        public static int GetRandomPostalCode()
        {
            Random _random = new Random();
            return _random.Next(20000, 89999);
        }
        public static void RefreshPage()
        {
            driver.Navigate().Refresh();
            CommonMethods.WaitForPageToLoadComplete(60);
        }
        public static bool IsElementEnabled(IWebElement element)
        {
            try
            {
                return element.Enabled;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                return false;
            }
        }
        public static bool IsElementEnabledByXpath(string xpath)
        {
            try
            {
                return driver.FindElement(By.XPath(xpath)).Enabled;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                return false;
            }
        }
        public static bool IsElementEnabledByXPath(string xpath)
        {
            try
            {
                return driver.FindElement(By.XPath(xpath)).Enabled;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                return false;
            }
        }
        public static bool IsElementEnabledByID(string id)
        {
            try
            {
                return driver.FindElement(By.Id(id)).Enabled;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                return false;
            }
        }
        public static bool IsElementEnabledByCSS(string css)
        {
            try
            {
                return driver.FindElement(By.CssSelector(css)).Enabled;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                return false;
            }
        }
        public static void KillSpecrun()
        {
            System.Diagnostics.Process[] process = System.Diagnostics.Process.GetProcessesByName("specrun.exe");
            foreach (System.Diagnostics.Process p in process)
            {
                if (!string.IsNullOrEmpty(p.ProcessName))
                {
                    try
                    {
                        p.Kill();
                    }
                    catch { }
                }
            }
        }
        public static string ConvertToHex(string color)
        {
            String[] num = color.Replace("rgba(", "").Replace(")", "").Split(new Char[] { ',' });
            int r = Int32.Parse(num[0].Trim());
            int g = Int32.Parse(num[1].Trim());
            int b = Int32.Parse(num[2].Trim());
            int a = Int32.Parse(num[3].Trim());
            //string hexValue = "#" + r.ToString("X2") + g.ToString("X1") + b.ToString("X2");
            string hexValue = "#" + r.ToString("X2") + g.ToString("X1") + b.ToString("X2") + a.ToString("X1");
            return hexValue;
        }
        //public static Boolean isCvgAvailableForMachine(string coverageType, string model, string searialNo)
        //{
        //    try
        //    {
        //        //InputDataFile InputDataFile = InputDataFilehelper.InputDataFile;
        //        string MethodName = "";
        //        string requestBodyContent = "";
        //        string baseUrl = "";
        //        //baseUrl = InputDataFile.getMachineBasedOnModelAndSerial;
        //        baseUrl = "https://komatsu-machine-apis-v2-qa.azurewebsites.net/api/Machines/" + model + "_" + searialNo;
        //        Dictionary<string, string> headerInfos = new Dictionary<string, string>();
        //        headerInfos.Add("Content-Type", "application/json");
        //        Dictionary<string, string> queryStrings = new Dictionary<string, string>();
        //        Method httpAction = Method.GET;
        //        //DataFormat dataFormat = DataFormat.Json;
        //        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        //        //RestServiceClient client = new RestServiceClient(baseUrl, dataFormat);
        //        client.ExecuteRestRequest(httpAction, MethodName, headerInfos, requestBodyContent, queryStrings, dataFormat);
        //        var Targetdata = client.RestApiResponse.Content;
        //        System.Net.HttpStatusCode responseCode = client.RestApiResponse.StatusCode;
        //        int responseCodeInt = (int)responseCode;
        //        dynamic stuff = JsonConvert.DeserializeObject(Targetdata);
        //        ArrayList coverageAL = new ArrayList();
        //        foreach (var item in stuff)
        //        {
        //            Console.WriteLine("id: {0}", item.wt);
        //            var warrantyItems = item.wt;
        //            foreach (var warranty in warrantyItems)
        //            {
        //                coverageAL.Add((string)warranty.ct);
        //            }
        //        }
        //        if (coverageAL.Contains(coverageType))
        //        {
        //            return true;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception("Exception occured in 'isCvgAvailableForMachine' method");
        //    }
        //}
        public static string ConvertToHexForFont(string color)
        {
            String[] num = color.Replace("rgba(", "").Replace(");", "").Split(new Char[] { ',' });
            int r = Int32.Parse(num[0].Trim());
            int g = Int32.Parse(num[1].Trim());
            int b = Int32.Parse(num[2].Trim());
            string hexValue = "#" + r.ToString("X2") + g.ToString("X1") + b.ToString("X2");
            return hexValue;
        }

        public static IList<IWebElement> collectionByXpath(string xpath)
        {
            IList<IWebElement> ele = null;
            ele = driver.FindElements(By.XPath(xpath));
            return ele;
        }
        public static void ClearTextFieldByID(string id)
        {
            try
            {
                driver.FindElement(By.Id(id)).Clear();
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void EnterTodaysdateByID(string id)
        {
            try
            {
                IWebElement element = driver.FindElement(By.Id(id));
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);
                element.SendKeys(OpenQA.Selenium.Keys.Enter);

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void EnterTomorrowdateByID(string id, int days)
        {
            try
            {
                IWebElement element = driver.FindElement(By.Id(id));
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.AddDays(days).ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);
                element.SendKeys(OpenQA.Selenium.Keys.Enter);

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void EnterEnddateByID(string id)
        {
            try
            {
                IWebElement element = driver.FindElement(By.Id(id));
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.AddDays(250).ToString("MM/dd/yyyy");
                //String datestring = todaysDate.ToString("MM/dd/yyyy");
                element.Clear();
                //datestring = datestring.AddDays(5);
                element.SendKeys(datestring);
                element.SendKeys(OpenQA.Selenium.Keys.Enter);

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetTodaysDate()
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.ToString("MM/dd/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetTodaysDateByDateFirst()
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.ToString("dd/MM/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetYesterdaysDateByDateFirst()
        {
            try
            {
                var yesterday = DateTime.Today.AddDays(-1);
                return yesterday.ToString("dd/MM/yyyy");
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        //public static void ExcelResultForReport()
        //{
        //    //var dataGridView1 = "";
        //    var fileName = CommonMethods.BasePath + "\\TestDataAccess\\ReportSummaryQA.xls";
        //    var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileName + "'; Extended Properties='Excel 8.0;HDR=YES;\'";
        //    using (OleDbConnection conn = new OleDbConnection(connectionString))
        //    {
        //        conn.Open();
        //        OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter
        //        ("Insert into [Sheet1$] (Status, Description) VALUES ('PASS', 'Sample Test Case')", conn);
        //        DataSet excelDataSet = new DataSet();
        //        objDA.Fill(excelDataSet);
        //        //dataGridView1.DataSource = excelDataSet.Tables[0];
        //        //dataGridView.DataSource = excelDataSet.Tables[0];
        //        //OleDbCommand cmd = new OleDbCommand();
        //        //cmd.Connection = conn;
        //        //cmd.CommandText = "Insert into[Sheet1$](Status, Description) VALUES('PASS', 'Sample Test Case')";
        //        //cmd.ExecuteNonQuery();
        //        //dataGridView1.DataSource = excelDataSet.Tables[0];
        //    }

        //    //In above code '[Sheet1$]' is the first sheet name with '$' as default selector,
        //    // with the help of data adaptor we can load records in dataset		

        //    //write data in EXCEL sheet (Insert data)
        //    //using (OleDbConnection conn = new OleDbConnection(connectionString))
        //    //{
        //    //    try
        //    //    {
        //    //        conn.Open();
        //    //        OleDbCommand cmd = new OleDbCommand();
        //    //        cmd.Connection = conn;
        //    //        cmd.CommandText = "Insert into[Sheet1$](Status, Description) VALUES('PASS', 'Sample Test Case')";
        //    //        cmd.ExecuteNonQuery();
        //    //        //cmd.ExecuteReader();
        //    //    }
        //    //    catch (Exception e)
        //    //    {
        //    //        //exception here
        //    //    }
        //    //    finally
        //    //    {
        //    //        conn.Close();
        //    //        conn.Dispose();
        //    //    }
        //    //}
        //}
        //public static void ExcelResultForReport1()
        //{

        //    var fileName = CommonMethods.BasePath + "\\TestDataAccess\\ReportSummaryQA.xls";
        //    var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileName + "'; Extended Properties='Excel 8.0;HDR=YES;\'";
        //    OleDbConnection conn = new OleDbConnection();
        //    conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileName + "'" + @"; Extended Properties=""Excel 8.0;HDR=YES;IMEX=1;ImportMixedTypes=Text;TypeGuessRows=()""";
        //    //OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter
        //    //    ("select * from [Sheet1$]", conn);
        //    //    DataSet excelDataSet = new DataSet();
        //    //    objDA.Fill(excelDataSet);
        //    OleDbCommand cmd = new OleDbCommand("Insert into [Sheet1$] (Status,Description) VALUES ('PASS','Sample Test Case')", conn);
        //    DataSet status = new DataSet();
        //    OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
        //    adapter.Fill(status);
        //    //DataGridView.DataGridViewControlCollection= status.Tables[0];

        //}
        //public static void ReportToExcel()
        //{
        //    try
        //    {
        //        var fileName = CommonMethods.BasePath + "\\TestDataAccess\\ReportSummaryQA.xls";
        //        //var sConnectionString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = {0}; Extended Properties='Excel 8.0;HDR=YES;FMT=Delimited;IMEX=1;';", fileName);
        //       var sConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source = '" + fileName + "';Extended Properties=\"Excel 8.0;HDR=YES;\"";
        //        var objConnection = new OleDbConnection(sConnectionString);
        //        objConnection.Open();
        //        OleDbCommand cmd = new OleDbCommand();
        //        cmd.Connection = objConnection;
        //        cmd.CommandText = @"Insert into [Sheet1$] (Status,Description) VALUES ('PASS','Sample Test Case');";
        //        cmd.ExecuteReader();

        //        DataTable dtExcelSchema;
        //        dtExcelSchema = cmd.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        //        string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"];
        //        DataSet ds = new DataSet();
        //        string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
        //        cmdExcel.CommandText = "SELECT ID, Name From [" + SheetName + "]";
        //        da.SelectCommand = cmdExcel;
        //        da.Fill(ds);
        //        objConnection.Dispose();
        //    }
        //    catch (Exception e)
        //    {
        //        CaptureScreenshot();
        //        LogFile.LogErrorInformation(e.ToString());
        //        SetupFile._status = "Fail";
        //        SetupFile._statusMessage = e.ToString();
        //        throw new Exception(e.ToString());
        //    }
        //}
        public static System.Data.DataTable ReportToExcelDemo()
        {

            var dsImportCSVtoDataSetReturn = new System.Data.DataTable();

            using (var objAdapter1 = new OleDbDataAdapter())
            {

                var fileName = CommonMethods.BasePath + "\\TestDataAccess\\ReportSummaryQA.xls";
                var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileName + "'; Extended Properties='Excel 8.0;HDR=YES;\'";
                var objConnection = new OleDbConnection(connectionString);
                objConnection.Open();
                var objCmdSelect = new OleDbCommand("Insert into [Sheet1$] (Status, Description) VALUES ('PASS', 'Sample Test Case')", objConnection);
                objAdapter1.SelectCommand = objCmdSelect;
                //objCmdSelect.CommandText= "Insert into [Sheet1$] (Status, Description) VALUES ('PASS', 'Sample Test Case')";
                objAdapter1.Fill(dsImportCSVtoDataSetReturn);
                //objConnection.Dispose();
            }

            return dsImportCSVtoDataSetReturn;
        }
        public static void UploadDocumentByXpath(string xpath, string filename)
        {
            IWebElement element = driver.FindElement(By.XPath(xpath));
            CommonMethods.JavaScriptClickByXPath(xpath);
            IWebElement frame = CommonMethods.driver.SwitchTo().ActiveElement();
            string path = CommonMethods.BasePath + @"\Images\" + filename;
            element.SendKeys(path);
            CommonMethods.SwitchToDefaultContent();
            Thread.Sleep(4000);
        }

        //public static void TakeSS()
        //{


        //    IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
        //    long clientHeight = (long)jse.ExecuteScript("return document.documentElement.clientHeight");
        //    long scrollHeight = (long)jse.ExecuteScript("return document.documentElement.scrollHeight");
        //    int screens = 0, xAxis = 0, yAxis = clientHeight.IntValue();
        //    String screenNames = "D:\\Screenshots\\Yash";
        //    for (screens = 0; ; screens++)
        //    {
        //        if (scrollHeight.intValue() - xAxis < clientHeight)
        //        {
        //            File crop = new File(screenNames + screens + ".jpg");
        //            FileUtils.copyFile(browser.getScreenshotAs(OutputType.FILE), crop);

        //            BufferedImage image = ImageIO.read(new FileInputStream(crop));
        //            int y_Axixs = scrollHeight.intValue() - xAxis;
        //            BufferedImage croppedImage = image.getSubimage(0, image.getHeight() - y_Axixs, image.getWidth(), y_Axixs);
        //            ImageIO.write(croppedImage, "jpg", crop);
        //            break;
        //        }

        //        FileUtils.copyFile(browser.getScreenshotAs(OutputType.FILE), new File(screenNames + screens + ".jpg"));
        //        jse.executeScript("window.scrollBy(" + xAxis + ", " + yAxis + ")");

        //        jse.executeScript("var elems = window.document.getElementsByTagName('*');"
        //                + "     for(i = 0; i < elems.length; i++) { "
        //                + "         var elemStyle = window.getComputedStyle(elems[i], null);"
        //                + "         if(elemStyle.getPropertyValue('position') == 'fixed' && elems[i].innerHTML.length != 0 ){"
        //                + "             elems[i].parentNode.removeChild(elems[i]); "
        //                + "}}");    // Sticky Content Removes
        //        xAxis += yAxis;
        //    }
        //    driver.quit();
        //}
        //public static void Takess()
        //{
        //    int screenWidth = Screen.GetBounds(new Point(0, 0)).Width;
        //    int screenHeight = Screen.GetBounds(new Point(0, 0)).Height;
        //    Bitmap bmpScreenShot = new Bitmap(screenWidth, screenHeight);
        //    Graphics gfx = Graphics.FromImage((Image)bmpScreenShot);
        //    gfx.CopyFromScreen(0, 0, 0, 0, new Size(screenWidth, screenHeight));
        //    string basePath = CommonMethods.BasePath;
        //    string path = basePath + @"\Screenshots\output\";
        //    bmpScreenShot.Save(path + "test.jpg", ImageFormat.Jpeg);
        //}

        public static void getCoordinates()
        {
            IWebElement Image1 = driver.FindElement(By.XPath("/html/body/div[1]/div"));

            //Used points class to get x and y coordinates of element.
            string point = Image1.GetAttribute("offsetLeft");
            string point1 = Image1.GetAttribute("width");
            //((IJavaScriptExecutor)driver).ExecuteScript("document.body.style.zoom = '60%';");
            //Locate element for which you wants to retrieve x y coordinates.
            IWebElement Image2 = driver.FindElement(By.XPath("/html/body/div[1]/div/form/div[1]"));

            //Used points class to get x and y coordinates of element.
            string point2 = Image2.GetAttribute("offsetLeft");
            string point3 = Image1.GetAttribute("width");
            //int xcord = point.getX();
            //System.out.println("Element's Position from left side Is "+xcord +" pixels.");
            //int ycord = point.getY();
            //System.out.println("Element's Position from top side Is "+ycord +" pixels.");
        }

        public static void CaptureScreenshot()
        {
            try
            {
                ScrollToTopOfPage();
                string basePath = CommonMethods.BasePath;
                string path = basePath + @"\Screenshots\output";
                //string path = basePath + @"\Screenshots\output\"+name;
                var filename = string.Empty + DateTime.Now.ToString("ddmmyyyyHHmmss");
                filename = path + @"\" + filename + ".jpg";
                // Get the Total Size of the Document
                long totalWidth_Long = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.body.clientWidth");
                long totalHeight_Long = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.body.clientHeight");

                if (totalHeight_Long >= 430)
                {

                    // Get the Size of the Viewport
                    long viewportWidth_Long = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.documentElement.clientWidth");
                    long viewportHeight_Long = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.documentElement.clientHeight");

                    int totalWidth = (int)totalWidth_Long;
                    int totalHeight = (int)totalHeight_Long;
                    int viewportWidth = (int)viewportWidth_Long;
                    int viewportHeight = (int)viewportHeight_Long;

                    // Split the Screen in multiple Rectangles
                    List<Rectangle> rectangles = new List<Rectangle>();
                    // Loop until the Total Height is reached
                    for (int i = 0; i < totalHeight; i += viewportHeight)
                    {
                        int newHeight = viewportHeight;
                        // Fix if the Height of the Element is too big
                        if (i + viewportHeight > totalHeight)
                        {
                            newHeight = totalHeight - i;
                        }
                        // Loop until the Total Width is reached
                        for (int ii = 0; ii < totalWidth; ii += viewportWidth)
                        {
                            int newWidth = viewportWidth;
                            // Fix if the Width of the Element is too big
                            if (ii + viewportWidth > totalWidth)
                            {
                                newWidth = totalWidth - ii;
                            }
                            // Create and add the Rectangle
                            Rectangle currRect = new Rectangle(ii, i, newWidth, newHeight);
                            rectangles.Add(currRect);
                        }
                    }

                    // Build the Image
                    var stitchedImage = new Bitmap(totalWidth, totalHeight);
                    // Get all Screenshots and stitch them together
                    Rectangle previous = Rectangle.Empty;
                    foreach (var rectangle in rectangles)
                    {
                        // Calculate the Scrolling (if needed)
                        if (previous != Rectangle.Empty)
                        {
                            int xDiff = rectangle.Right - previous.Right;
                            int yDiff = rectangle.Bottom - previous.Bottom;
                            // Scroll
                            ((IJavaScriptExecutor)driver).ExecuteScript(String.Format("window.scrollBy({0}, {1})", xDiff, yDiff));
                            System.Threading.Thread.Sleep(2000);
                        }

                        // Take Screenshot
                        var screenshot = ((ITakesScreenshot)driver).GetScreenshot();

                        // Build an Image out of the Screenshot
                        Image screenshotImage;
                        using (MemoryStream memStream = new MemoryStream(screenshot.AsByteArray))
                        {
                            screenshotImage = Image.FromStream(memStream);
                        }

                        // Calculate the Source Rectangle
                        Rectangle sourceRectangle = new Rectangle(viewportWidth - rectangle.Width, viewportHeight - rectangle.Height, rectangle.Width, rectangle.Height);

                        // Copy the Image
                        using (Graphics g = Graphics.FromImage(stitchedImage))
                        {
                            g.DrawImage(screenshotImage, rectangle, sourceRectangle, GraphicsUnit.Pixel);
                        }

                        // Set the Previous Rectangle
                        previous = rectangle;
                    }
                    stitchedImage.Save(filename);
                    // The full Screenshot is now in the Variable "stitchedImage"
                    Console.WriteLine(@"Screenshot: {0}", new Uri(filename));
                }
                else
                {
                    CaptureScreenshotExtentReport();
                }
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
        public static void WaitUntilElementToBeClickableIsDisplayedByXpath(int Time, string XPath)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath(XPath)));
        }
        public static void WaitUntilElementToBeClickableIsDisplayedByCss(int Time, string CssSelector)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(CssSelector)));
        }
        public static void WaitForElementExistByCss(int Time, string CssSelector)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.CssSelector(CssSelector)));
        }
        public static void WaitForElementExistByID(int Time, string ID)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.Id(ID)));
        }
        public static void WaitForElementExistByXpath(int Time, string XPath)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.XPath(XPath)));
        }

        public static void FluentWait(string xpath, int millisec)
        {
            DefaultWait<IWebElement> wait = new DefaultWait<IWebElement>(driver.FindElement(By.XPath(xpath)));
            wait.Timeout = TimeSpan.FromMinutes(2);
            wait.PollingInterval = TimeSpan.FromMilliseconds(millisec);

        }
        private void btnAccessEmail_Click(object sender, EventArgs e)
        {
            //Microsoft.Office.Interop.Outlook.Application myApp = new Microsoft.Office.Interop.Outlook.ApplicationClass();
            //Microsoft.Office.Interop.Outlook.NameSpace mapiNameSpace = myApp.GetNamespace("MAPI");
            //Microsoft.Office.Interop.Outlook.MAPIFolder myInbox = mapiNameSpace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderInbox);
            //if (myInbox.Items.Count > 0)
            //{
            //    // Grab the Subject
            //    string lblSubject = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).Subject;
            //    //Grab the Attachment Name
            //    if (((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).Attachments.Count > 0)
            //    {
            //        string lblAttachmentName = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).Attachments[1].FileName;
            //    }
            //    else
            //    {
            //        string lblAttachmentName = "No Attachment";
            //    }
            //    // Grab the Body
            //    string txtBody = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).Body;
            //    // Sender Name
            //    string lblSenderName = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).SenderName;
            //    // Sender Email
            //    string lblSenderEmail = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).SenderEmailAddress;
            //    // Creation date
            //    string lblCreationdate = ((Microsoft.Office.Interop.Outlook.MailItem)myInbox.Items[1]).CreationTime.ToString();
            //}
            //else
            //{
            //    MessageBox.Show("There are no emails in your Inbox.");
            //}
        }

        public static void WaitUntilElementToBeDisplayedByID(int Time, string Id)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.Id(Id)));
        }

        public static void WaitUntilElementToBeDisplayedByXpath(int Time, string xpath)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.XPath(xpath)));
        }

        public static void WaitUntilElementToBeDisplayedByCSS(int Time, string Id)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.CssSelector(Id)));
        }

        public static void ScriollMouseHoverClickByXPath(string ele)
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath(ele));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                Thread.Sleep(1000);
                ////*[@id='AppointmentList']/div[2]/div[5]/div[2]
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", element);
                var action = new Actions(driver);
                action.MoveToElement(element).ClickAndHold().Perform();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static IWebElement ClickOnInvisibleElement(By by)
        {
            IWebElement element = CommonMethods.driver.FindElement(by);
            ((IJavaScriptExecutor)CommonMethods.driver).ExecuteScript("arguments[0].hidden = false;", element);
            element.Click();
            ((IJavaScriptExecutor)CommonMethods.driver).ExecuteScript("arguments[0].hidden = true;", element);
            return element;
        }
        public static void WaitUntilElementToBeDisplayedByLinkText(int Time, string linktext)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(Time));
            wait.Until(ExpectedConditions.ElementExists(By.LinkText(linktext)));
        }


        public static void ScrollIntoViewbyXpath(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                //IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.XPath(xpath)) });


            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void JavaScriptExe(string xpath)
        {
            try
            {
                IWebElement ele = driver.FindElement(By.XPath(xpath));
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript("arguments[0].scrollIntoView(true);", ele);
                string hlJavaScript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color; green"";";
                //IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                executor.ExecuteScript(hlJavaScript, new object[] { driver.FindElement(By.XPath(xpath)) });
            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void DeleteFiles()
        {
            CommonMethods.ExcelClose();
            Thread.Sleep(5000);
            //string Path = CommonMethods.BasePath;
            //string[] filePaths = Directory.GetFiles(Path + @"\Downloads\");
            int threadId = Thread.CurrentThread.ManagedThreadId;
            string downloadDirPath = CommonMethods.BasePath + @"\Downloads" + @"\Downloads" + "_" + threadId + @"\";
            string[] filePaths = Directory.GetFiles(downloadDirPath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(filePath))
                {

                    //foreach (Process clsProcess in Process.GetProcesses())
                    //{
                    //    string[]  f = filePath.Split(new Char[] { '\\' });
                    //    if (clsProcess.ProcessName.Contains(f[5]))
                    //    {
                    //        //To know if it works
                    //        //MessageBox.Show(clsProcess);
                    //        clsProcess.Kill();
                    //    }
                    //}
                    //var stream = File.Open(filePath, FileMode.Open);
                    //var reader = new StreamReader(stream);
                    CommonMethods.ExcelClose();
                    File.Delete(filePath);
                }
            }
        }
        public static void DeleteFilesKomatsuReports()
        {
            //foreach (Process clsProcess in Process.GetProcesses())
            //{

            //    if (clsProcess.ProcessName.EndsWith(".pdf"))
            //    {
            //        clsProcess.Kill();
            //        //process killed, return true 
            //    }
            //}
            //proce
            Thread.Sleep(5000);
            string destinationPath = CommonMethods.BasePath + @"\KomatsuReports\";
            string[] filePaths = Directory.GetFiles(destinationPath);
            foreach (string filePath in filePaths)
            {
                if (File.Exists(filePath))
                {
                    string[] filePaths1 = Directory.GetFiles(destinationPath);
                    File.Delete(filePath);
                }

            }


        }
        public static bool IsPDFHeader(string fileName)
        {
            byte[] buffer = null;
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            long numBytes = new FileInfo(fileName).Length;
            //buffer = br.ReadBytes((int)numBytes);
            buffer = br.ReadBytes(5);

            var enc = new ASCIIEncoding();
            var header = enc.GetString(buffer);

            //%PDF-1.0
            // If you are loading it into a long, this is (0x04034b50).
            if (buffer[0] == 0x25 && buffer[1] == 0x50
                && buffer[2] == 0x44 && buffer[3] == 0x46)
            {
                return header.StartsWith("%PDF-");
            }
            return false;

        }
        public static bool IsZipFHeader(string fileName)
        {
            byte[] buffer = null;
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            long numBytes = new FileInfo(fileName).Length;
            //buffer = br.ReadBytes((int)numBytes);
            buffer = br.ReadBytes(5);

            var enc = new ASCIIEncoding();
            var header = enc.GetString(buffer);

            //%PDF-1.0
            // If you are loading it into a long, this is (0x04034b50).
            if (buffer[0] == 0x25 && buffer[1] == 0x50
                && buffer[2] == 0x44 && buffer[3] == 0x46)
            {
                return header.EndsWith("@fln");
            }
            return false;

        }
        public static void SwitchToMyKomatsuManualWindow()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);

                string ActualResult = CommonMethods.GetElementTextByCSS("div.sectionHeader").Trim();
                string ExpectedResult = "Operator and Maintenance";
                Assert.AreEqual(ExpectedResult, ActualResult);
                Thread.Sleep(5000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }

        public static void SwitchToMyKomatsuGeneralDocsWindow()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string status = CommonMethods.GetElementAttributeValueByID("plugin", "type").Trim();
                Assert.AreEqual("application/pdf", status);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwithchTo()
        {
            //Actions newTab = new Actions(CommonMethods.driver);
            //newTab.KeyDown(OpenQA.Selenium.Keys.Control).KeyUp(OpenQA.Selenium.Keys.Shift).Build().Perform();
            driver.FindElement(By.CssSelector("body")).SendKeys(OpenQA.Selenium.Keys.Control + "t");
        }
        public static void MoveFolder(string sourceFile, string destinationFile)
        {
            //string sourceFile = @"C:\Users\Public\public\test.txt";
            //string destinationFile = @"C:\Users\Public\private\test.txt";

            // To move a file or folder to a new location:
            //System.IO.File.Move(sourceFile, destinationFile);

            // To move an entire directory. To programmatically modify or combine
            // path strings, use the System.IO.Path class.
            //System.IO.Directory.Move(sourceFile, destinationFile);
            if (Directory.Exists(sourceFile))
            {
                foreach (var file in new DirectoryInfo(sourceFile).GetFiles())
                {
                    file.MoveTo($@"{destinationFile}\{file.Name}");
                }
            }
        }
        public static void SwitchToFAQ()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);

                string ActualResult = CommonMethods.GetElementAttributeValueByID("plugin", "type").Trim();
                Assert.IsTrue(ActualResult.Contains("pdf"));
                Thread.Sleep(5000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwitchToKOWA()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string url = driver.Url;
                Assert.IsTrue(url.Contains("http://www.kowaonline.com/auth/login?targetUri=%2F"));
                Thread.Sleep(2000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwitchToShop()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string url = driver.Url;
                Assert.AreEqual("https://www.shamrockresource.com/komatsu/Home/tabid/7978/Default.aspx", url);
                Thread.Sleep(2000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwitchToFinancials()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string url = driver.Url;
                Assert.AreEqual("https://www.komatsufinancial.com/", url);
                Thread.Sleep(2000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void SwitchToWarranty()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string url = driver.Url;
                Assert.AreEqual("https://pwarranty.komatsuamerica.com/sap/bc/bsp/sap/zkac/default.htm", url);
                Thread.Sleep(2000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        //public static void SwitchToNewEquipment()
        //{
        //    var mainWindowHandle = driver.CurrentWindowHandle;
        //    var windowHandles = driver.WindowHandles;
        //    foreach (var windowHandle in windowHandles)
        //    {
        //        if (mainWindowHandle == windowHandle)
        //            continue;
        //        driver.SwitchTo().Window(windowHandle);
        //        string url = driver.Url;
        //        Assert.AreEqual("https://www.komatsuamerica.com/", url);
        //        Thread.Sleep(2000);
        //        driver.Close();
        //        driver.SwitchTo().Window(mainWindowHandle);
        //        break;
        //    }
        //}
        public static void SwitchToUserGuide(string str)
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                string url = driver.Url;
                Assert.AreEqual(str, url);
                Thread.Sleep(2000);
                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static string GetYesterdaysDateByMonthFirst()
        {
            try
            {
                var yesterday = DateTime.Today.AddDays(-1);
                return yesterday.ToString("MM/dd/yyyy");
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string GetRandomName(string name)
        {
            Random _random = new Random();
            return string.Format(name, _random.Next(100, 999));
        }
        public static string GetRandomNameALone(string name)
        {
            Random _random = new Random();
            return string.Format(name);
        }
        public static string GetRandomEmail1(string str)
        {
            Random _random = new Random();
            return string.Format(str, _random.Next(10000, 99999));
        }
        public static void MouseHoverClickByxpath(string xpath, string xpath1)
        {
            IWebElement ele = driver.FindElement(By.XPath(xpath));
            //IWebElement ele1 = driver.FindElement(By.XPath(xpath1));
            try
            {
                var action = new Actions(driver);
                action.MoveToElement(ele).Perform();
                Thread.Sleep(2000);
                JavaScriptClickByXPath(xpath1);
                action.Release();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void NextMonth(IWebElement element)
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                String datestring = todaysDate.AddMonths(1).ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void FileUpload(IWebElement ele, string str)
        {
            IWebElement frame = CommonMethods.driver.SwitchTo().ActiveElement();
            string path = CommonMethods.BasePath + @"\Images\" + str;
            ele.SendKeys(path);
        }
        public static void verifyPDFFileDownloaded()
        {
            string Path = CommonMethods.BasePath;
            string[] filePaths = Directory.GetFiles(Path + @"\Downloads\");
            foreach (string filePath in filePaths)
            {
                if (File.Exists(filePath))
                {
                    Assert.IsTrue(filePath.Contains("DownloadUserManuals.pdf"));
                }
            }
        }
        public static string TypeYearDate(IWebElement element, int str)
        {
            try
            {
                DateTime todaysDate = DateTime.Today;
                String datestring = DateTime.Now.AddYears(str).ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);
                return datestring;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SwitchMyKomatsuWindow()
        {
            string URL = "";
            string Env = ConfigurationManager.AppSettings["Environment"];
            if (Env.ToLower() == "qa")
            {
                URL = "mykomatsuqa";
            }
            else
            {
                URL = "mykomatsuDev";
            }
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                //LoginSteps.GivenAndILaunchTheKomatsuURL(URL);
                //LoginSteps.GivenIEnterUsernamePassword("TC001username", "password");
                //LoginSteps.WhenIClickSignIn();

                driver.Close();
                driver.SwitchTo().Window(mainWindowHandle);
                break;
            }
        }
        public static void MouseHoverClickByXpath(string xpath, string xpath1)
        {
            IWebElement ele = driver.FindElement(By.XPath(xpath));
            IWebElement ele1 = driver.FindElement(By.XPath(xpath1));
            try
            {
                var action = new Actions(driver);
                action.MoveToElement(ele).Perform();
                Thread.Sleep(2000);
                //JavaScriptClickByXPath(xpath1);
                //action.MoveToElement(ele1).Click().SendKeys(ele1,"ssss").ContextClick().Build();
                //action.MoveToElement(ele1).Click().ContextClick().Build();
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string ConvertMonthDay(string str)
        {
            try
            {
                if (str == "1")
                {
                    str = "01";
                }
                else if (str == "2")
                {
                    str = "02";
                }
                else if (str == "3")
                {
                    str = "03";
                }
                else if (str == "4")
                {
                    str = "04";
                }
                else if (str == "5")
                {
                    str = "05";
                }
                else if (str == "6")
                {
                    str = "06";
                }
                else if (str == "7")
                {
                    str = "07";
                }
                else if (str == "8")
                {
                    str = "08";
                }
                else if (str == "9")
                {
                    str = "09";
                }
                return str;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static void SwitchToWindow()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                break;
            }
        }
        public static void CloseWindow()
        {
            var mainWindowHandle = driver.CurrentWindowHandle;
            var windowHandles = driver.WindowHandles;
            foreach (var windowHandle in windowHandles)
            {
                if (mainWindowHandle == windowHandle)
                    continue;
                driver.SwitchTo().Window(windowHandle);
                driver.Close();
                break;
            }
        }
        public static void OpenNewTabByXpath()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.open();");
            CommonMethods.driver.SwitchTo().Window(CommonMethods.driver.WindowHandles.Last());
        }
        public static void NavigateToFirstTab()
        {
            CommonMethods.driver.SwitchTo().Window(CommonMethods.driver.WindowHandles.First());
        }
        public static void NavigateToLastTab()
        {
            CommonMethods.driver.SwitchTo().Window(CommonMethods.driver.WindowHandles.Last());
        }
        public static string TypeYearToDate(IWebElement element)
        {
            try
            {
                DateTime todaysDate = DateTime.Today;
                String datestring = todaysDate.ToString("MM/dd/yyyy");
                element.Clear();
                element.SendKeys(datestring);
                return datestring;
            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string DynamicElementId(string elementXPath)
        {
            string key = string.Empty;
            try
            {
                if (!string.IsNullOrWhiteSpace(elementXPath))
                {
                    var items = CommonMethods.driver.FindElements(By.XPath(elementXPath));
                    int count = items != null ? items.Count() : 0;
                    if (count > 0)
                    {
                        for (int index = 1; index <= count; index++)
                        {
                            string xpath = elementXPath + "[" + index + "]";
                            bool lastyearenable = CommonMethods.IsElementDisplayedByXpath(xpath);
                            if (lastyearenable)
                            {
                                key = xpath;
                                return key;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return key;
        }
        public static void JavaScriptRightClick(string xpath)
        {
            IWebElement ele = driver.FindElement(By.XPath(xpath));
            try
            {
                var action = new Actions(driver);
                Thread.Sleep(2000);
                action.ContextClick(ele).Build().Perform();

            }
            catch (Exception e)
            {
                LogFile.LogInformation(e.ToString());
                CaptureScreenshot();
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }

        public static string currentdate()
        {
            try
            {
                DateTime todaysDate = DateTime.Now.Date;
                string datestring = todaysDate.ToString("MM/dd/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string currentDateAndTime()
        {
            try
            {
                DateTime now = DateTime.Now;
                return now.ToString();

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string Futuredate()
        {
            try
            {
                DateTime todaysDate = DateTime.Today.AddDays(10);
                string datestring = todaysDate.ToString("MM/dd/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string AddDays(int NoOfDays, string format)
        {
            try
            {
                DateTime todaysDate = DateTime.Today.AddDays(10);
                string datestring = todaysDate.ToString("dd/MM/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string Futuredate1()
        {
            try
            {
                DateTime todaysDate = DateTime.Today.AddDays(10);
                string datestring = todaysDate.ToString("dd/mm/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static string FutureMonth()
        {
            try
            {
                DateTime todaysDate = DateTime.Today.AddMonths(2);
                string datestring = todaysDate.ToString("dd/mm/yyyy");
                return datestring;

            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static DateTime NextMonth(DateTime date)
        {
            if (date.Day != DateTime.DaysInMonth(date.Year, date.Month))
                return date.AddMonths(1);
            else
                return date.AddDays(1).AddMonths(1).AddDays(-1);
        }
        public static string AddSmartMonths(DateTime d, int nMonths)
        {
            try
            {
                int year = d.Year;
                int month = d.Month;
                int day = d.Day;

                if ((day == 30) && (day < DateTime.DaysInMonth(year, month)))
                    d = d.AddDays(1);
                else if ((month == 1) && (day > 32))
                    d = new DateTime(year, month, 31);


                return d.AddMonths(nMonths).ToString();


            }
            catch (Exception e)
            {
                CaptureScreenshot();
                LogFile.LogErrorInformation(e.ToString());
                SetupFile._status = "Fail";
                SetupFile._statusMessage = e.ToString();
                throw new Exception(e.ToString());
            }
        }
        public static DateTime AddMonths(DateTime value, int numberOfMonths)
        {
            bool isEndDate = DateTime.DaysInMonth(value.Year, value.Month) == value.Day;
            if (isEndDate)
            {
                var newDateTime = value.AddMonths(numberOfMonths);
                return new DateTime(newDateTime.Year, newDateTime.Month, DateTime.DaysInMonth(newDateTime.Year, newDateTime.Month));
            }
            return value.AddMonths(numberOfMonths);
        }
        //public static bool ContainsClass(string className, double time)
        //{
        //    //WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
        //    //wait.Until(ExpectedConditions.ElementExists(By.ClassName(className)));
        //    return CheckStringForClass(driver.PageSource, className);
        //}
        //public static bool CheckStringForClass(string text, string className)
        //{
        //    if (!string.IsNullOrWhiteSpace(text))
        //    {
        //        string pattern = string.Format(".*class[\\s]?=[\\s]?.*[\\s'\"]{0}[\\s'\"].*.*", className);
        //        Match m = Regex.Match(text, className, RegexOptions.IgnoreCase);
        //        return m.Success;
        //    }
        //    return false;
        //}
        public static bool IsRadioButtonSelected(IList<IWebElement> ele)
        {
            IList<IWebElement> rdBtn_Sex = ele;
            // Create a boolean variable which will hold the value (True/False)
            Boolean bValue = false;
            // This statement will return True, in case of first Radio button is selected
            return rdBtn_Sex.ElementAt(0).Selected;
        }
    }
}

    

