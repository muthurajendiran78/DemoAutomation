﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAutomation.ReusableFiles
{
    class LogFile
    {

        public static void LogInformation(string str)
        {
            Console.WriteLine(str);
        }

        public static void LogErrorInformation(string str)
        {
            Console.WriteLine(str);
        }

    }
}
