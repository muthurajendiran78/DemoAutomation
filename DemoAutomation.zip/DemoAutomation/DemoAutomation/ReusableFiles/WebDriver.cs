﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoAutomation.ReusableFiles
{
    class WebDriver
    {
        public IWebDriver _currentWebDriver;
        public static string BrowserDriverPath = ConfigurationManager.AppSettings["BrowserDriverPath"];
        //private Local browserStackLocal;
        public IWebDriver Current
        {

            get
            {

                if (_currentWebDriver != null)
                    return _currentWebDriver;
                BrowserDriverPath = CommonMethods.BasePath + BrowserDriverPath;

                switch (BrowserConfig)
                {
                    case "IE":

                        //_currentWebDriver = new InternetExplorerDriver(new InternetExplorerOptions() { IgnoreZoomLevel = true }) { Url = SeleniumBaseUrl };
                        InternetExplorerOptions op = new InternetExplorerOptions();
                        op.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        op.EnableNativeEvents = true;
                        op.IgnoreZoomLevel = true;
                        InternetExplorerDriverService serviceie = InternetExplorerDriverService.CreateDefaultService(BrowserDriverPath + "IEDriver");
                        _currentWebDriver = new InternetExplorerDriver(serviceie, op);
                        break;
                    case "Chrome":
                        //_currentWebDriver = new ChromeDriver() { Url = SeleniumBaseUrl };
                        ChromeOptions option = new ChromeOptions();
                        ChromeDriverService service = ChromeDriverService.CreateDefaultService(CommonMethods.BasePath + @"\Drivers\ChromeDriver");
                        service.SuppressInitialDiagnosticInformation = true;
                        option.AddArgument("--disable-extensions");
                        option.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option.AddUserProfilePreference("credentilas_enabled_service", false);
                        option.AddArgument("--start-maximized");
                        option.AddArgument("--allow-file-acces-from-file");
                        option.AddArgument("--disable-popup-blocking");
                        option.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option.AddUserProfilePreference("intl.accept_languages", "nl");
                        option.AddUserProfilePreference("disable-popup-blocking", "true");
                        int threadId = Thread.CurrentThread.ManagedThreadId;
                        string downloadDirPath = CommonMethods.BasePath + @"\Downloads" + @"\Downloads" + "_" + threadId + @"\";

                        System.IO.Directory.CreateDirectory(downloadDirPath);
                        option.AddUserProfilePreference("download.default_directory", downloadDirPath);
                        option.AddUserProfilePreference("plugins.always_open_pdf_externally", true);

                        option.AddUserProfilePreference("profile.default_content_setting_values.automatic_downloads", 1);
                        //option.AddArgument("--headless");
                        //user agent
                        //option.AddArgument("--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25");
                        _currentWebDriver = new ChromeDriver(service, option);
                        break;
                    case "Firefox":
                        //_currentWebDriver = new FirefoxDriver() { Url = SeleniumBaseUrl };
                        var ffOptions = new FirefoxOptions();
                        ffOptions.BrowserExecutableLocation = @"C:\Program Files\Mozilla Firefox\firefox.exe";
                        ffOptions.LogLevel = FirefoxDriverLogLevel.Default;
                        ffOptions.Profile = new FirefoxProfile { AcceptUntrustedCertificates = true };
                        FirefoxDriverService ffservice = FirefoxDriverService.CreateDefaultService(CommonMethods.BasePath + @"\Drivers\Firefox\new");
                        ffservice.FirefoxBinaryPath = @"C:\Program Files\Mozilla Firefox\firefox.exe";
                        ffservice.SuppressInitialDiagnosticInformation = true;
                        ffOptions.AddArgument("--disable-extensions");
                        FirefoxProfile profile = new FirefoxProfile();
                        profile.SetPreference("profile.password_manager_enabled", false);
                        profile.SetPreference("credentilas_enabled_service", false);
                        profile.SetPreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //profile.SetPreference("intl.accept_languages", "nl");
                        profile.SetPreference("disable-popup-blocking", "true");
                        ffOptions.AddArgument("--start-maximized");
                        ffOptions.AddArgument("--allow-file-acces-from-file");
                        ffOptions.AddArgument("--disable-popup-blocking");
                        profile.SetPreference("log", "{level: trace}");
                        //DesiredCapabilities dc = DesiredCapabilities.Firefox();
                        //dc.SetCapability("marionette", true);
                        //dc.SetCapability(FirefoxDriver.ProfileCapabilityName, ffOptions);
                        //dc.SetCapability(FirefoxDriver.ProfileCapabilityName, profile);
                        _currentWebDriver = new FirefoxDriver(ffservice, ffOptions, TimeSpan.FromSeconds(120));
                        break;
                    case "MacSafari":
                        ChromeOptions option14 = new ChromeOptions();
                        ChromeDriverService service14 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "Chrome");
                        service14.SuppressInitialDiagnosticInformation = true;
                        option14.AddArgument("--disable-extensions");
                        option14.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option14.AddUserProfilePreference("credentilas_enabled_service", false);
                        option14.AddArgument("--start-maximized");
                        option14.AddArgument("--allow-file-acces-from-file");
                        option14.AddArgument("--disable-popup-blocking");
                        option14.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option14.AddUserProfilePreference("intl.accept_languages", "nl");
                        option14.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option14.AddArgument("--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8");
                        _currentWebDriver = new ChromeDriver(service14, option14);
                        break;
                    case "AndroidMarshmallow":
                        ChromeOptions option1 = new ChromeOptions();
                        ChromeDriverService service23 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service23.SuppressInitialDiagnosticInformation = true;
                        option1.AddArgument("--disable-extensions");
                        option1.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option1.AddUserProfilePreference("credentilas_enabled_service", false);
                        option1.AddArgument("--start-maximized");
                        option1.AddArgument("--allow-file-acces-from-file");
                        option1.AddArgument("--disable-popup-blocking");
                        option1.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option1.AddUserProfilePreference("intl.accept_languages", "nl");
                        option1.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option1.AddArgument("--user-agent=Mozilla/5.0 (Linux; Android 6.0.1; SM-J510FN Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.124 Mobile Safari/537.36");
                        _currentWebDriver = new ChromeDriver(service23, option1);
                        break;
                    case "AndroidNougat":
                        ChromeOptions option11 = new ChromeOptions();
                        ChromeDriverService service11 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service11.SuppressInitialDiagnosticInformation = true;
                        option11.AddArgument("--disable-extensions");
                        option11.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option11.AddUserProfilePreference("credentilas_enabled_service", false);
                        option11.AddArgument("--start-maximized");
                        option11.AddArgument("--allow-file-acces-from-file");
                        option11.AddArgument("--disable-popup-blocking");
                        option11.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option11.AddUserProfilePreference("intl.accept_languages", "nl");
                        option11.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option11.AddArgument("--user-agent=Mozilla/5.0 (Linux; Android 7.0; Moto G (4) Build/NPJS25.93-14-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36");
                        _currentWebDriver = new ChromeDriver(service11, option11);
                        break;
                    case "AndroidLollipop":
                        ChromeOptions option12 = new ChromeOptions();
                        ChromeDriverService service12 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service12.SuppressInitialDiagnosticInformation = true;
                        option12.AddArgument("--disable-extensions");
                        option12.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option12.AddUserProfilePreference("credentilas_enabled_service", false);
                        option12.AddArgument("--start-maximized");
                        option12.AddArgument("--allow-file-acces-from-file");
                        option12.AddArgument("--disable-popup-blocking");
                        option12.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option12.AddUserProfilePreference("intl.accept_languages", "nl");
                        option12.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option12.AddArgument("--user-agent=Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36");
                        _currentWebDriver = new ChromeDriver(service12, option12);
                        break;
                    case "IPadSafari":
                        ChromeOptions option13 = new ChromeOptions();
                        ChromeDriverService service13 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service13.SuppressInitialDiagnosticInformation = true;
                        option13.AddArgument("--disable-extensions");
                        option13.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option13.AddUserProfilePreference("credentilas_enabled_service", false);
                        option13.AddArgument("--start-maximized");
                        option13.AddArgument("--allow-file-acces-from-file");
                        option13.AddArgument("--disable-popup-blocking");
                        option13.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option13.AddUserProfilePreference("intl.accept_languages", "nl");
                        option13.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option13.AddArgument("--user-agent=Mozilla/5.0 (iPad; CPU OS 10_2_1 like Mac OS X) AppleWebKit/602.4.6 (KHTML, like Gecko) Version/10.0 Mobile/14D27 Safari/602.1");
                        _currentWebDriver = new ChromeDriver(service13, option13);
                        break;
                    case "IPadChrome":
                        ChromeOptions option19 = new ChromeOptions();
                        ChromeDriverService service19 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service19.SuppressInitialDiagnosticInformation = true;
                        option19.AddArgument("--disable-extensions");
                        option19.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option19.AddUserProfilePreference("credentilas_enabled_service", false);
                        option19.AddArgument("--start-maximized");
                        option19.AddArgument("--allow-file-acces-from-file");
                        option19.AddArgument("--disable-popup-blocking");
                        option19.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option19.AddUserProfilePreference("intl.accept_languages", "nl");
                        option19.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option19.AddArgument("--user-agent=Mozilla/5.0 (iPad; CPU OS 10_2_1 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/61.0.3163.73 Mobile/14D27 Safari/602.1");
                        _currentWebDriver = new ChromeDriver(service19, option19);
                        break;
                    case "IPhone6sSafari":
                        ChromeOptions option15 = new ChromeOptions();
                        ChromeDriverService service15 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service15.SuppressInitialDiagnosticInformation = true;
                        option15.AddArgument("--disable-extensions");
                        option15.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option15.AddUserProfilePreference("credentilas_enabled_service", false);
                        option15.AddArgument("--start-maximized");
                        option15.AddArgument("--allow-file-acces-from-file");
                        option15.AddArgument("--disable-popup-blocking");
                        option15.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option15.AddUserProfilePreference("intl.accept_languages", "nl");
                        option15.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option15.AddArgument("--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_1 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/14A403 Safari/602.1");
                        _currentWebDriver = new ChromeDriver(service15, option15);
                        break;
                    case "IPhone6sChrome":
                        ChromeOptions option16 = new ChromeOptions();
                        ChromeDriverService service16 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service16.SuppressInitialDiagnosticInformation = true;
                        option16.AddArgument("--disable-extensions");
                        option16.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option16.AddUserProfilePreference("credentilas_enabled_service", false);
                        option16.AddArgument("--start-maximized");
                        option16.AddArgument("--allow-file-acces-from-file");
                        option16.AddArgument("--disable-popup-blocking");
                        option16.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option16.AddUserProfilePreference("intl.accept_languages", "nl");
                        option16.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option16.AddArgument("--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 10_0_1 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/61.0.3163.73 Mobile/14A403 Safari/602.1");
                        _currentWebDriver = new ChromeDriver(service16, option16);
                        break;
                    case "Win7IE9":
                        ChromeOptions option17 = new ChromeOptions();
                        ChromeDriverService service17 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service17.SuppressInitialDiagnosticInformation = true;
                        option17.AddArgument("--disable-extensions");
                        option17.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option17.AddUserProfilePreference("credentilas_enabled_service", false);
                        option17.AddArgument("--start-maximized");
                        option17.AddArgument("--allow-file-acces-from-file");
                        option17.AddArgument("--disable-popup-blocking");
                        option17.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option17.AddUserProfilePreference("intl.accept_languages", "nl");
                        option17.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option17.AddArgument("--user-agent=Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)");
                        _currentWebDriver = new ChromeDriver(service17, option17);
                        break;
                    case "Win7IE10":
                        ChromeOptions option18 = new ChromeOptions();
                        ChromeDriverService service18 = ChromeDriverService.CreateDefaultService(BrowserDriverPath + "ChromeDriver");
                        service18.SuppressInitialDiagnosticInformation = true;
                        option18.AddArgument("--disable-extensions");
                        option18.AddUserProfilePreference("profile.password_manager_enabled", false);
                        option18.AddUserProfilePreference("credentilas_enabled_service", false);
                        option18.AddArgument("--start-maximized");
                        option18.AddArgument("--allow-file-acces-from-file");
                        option18.AddArgument("--disable-popup-blocking");
                        option18.AddUserProfilePreference("download.default_directory", CommonMethods.BasePath + @"\Downloads\");
                        //option18.AddUserProfilePreference("intl.accept_languages", "nl");
                        option18.AddUserProfilePreference("disable-popup-blocking", "true");
                        //user agent
                        option18.AddArgument("--user-agent=Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)");
                        _currentWebDriver = new ChromeDriver(service18, option18);
                        break;
                    case "Edge":
                        //string serverPath = @"D:\Workspace\Softura Automation Testing\BDD\DigitalSignUp\BDDSpecflowFrameworkSpecrunner\BDDSpecflowFrameworkSpecrunner\Drivers\Edge";
                        string serverPath = BrowserDriverPath + "Edge";
                        EdgeOptions optionsEdge = new EdgeOptions();
                        //optionsEdge.PageLoadStrategy = EdgePageLoadStrategy.Eager;
                        _currentWebDriver = new EdgeDriver(serverPath, optionsEdge);

                        break;
                    case "iPhone7":
                        //DesiredCapabilities capability = DesiredCapabilities.Chrome();
                        ////browserStackLocal = new Local();
                        ////                  List<KeyValuePair<string, string>> bsLocalArgs = new List<KeyValuePair<string, string>>() {
                        ////  new KeyValuePair<string, string>("key", "ks4EQsKUm9pj1Z334RsZ")
                        ////};
                        //if (capability.GetCapability("browserstack.local") != null && capability.GetCapability("browserstack.local").ToString() == "true")
                        //{
                        //    browserStackLocal = new Local();
                        //    List<KeyValuePair<string, string>> bsLocalArgs = new List<KeyValuePair<string, string>>() {
                        //            new KeyValuePair<string, string>("key", "o2R5cBxcqazByzJjtp32")
                        //            };
                        //    browserStackLocal.start(bsLocalArgs);
                        //}
                        //browserStackLocal.start(bsLocalArgs);

                        //capability.SetCapability("browserstack.user", "gunasekars1");
                        //capability.SetCapability("browserstack.key", "ks4EQsKUm9pj1Z334RsZ");
                        //capability.SetCapability("browserstack.user", "softura1");
                        //capability.SetCapability("browserstack.key", "o2R5cBxcqazByzJjtp32");
                        ////windows 7
                        ////capability.SetCapability("os", "Windows");
                        ////capability.SetCapability("os_version", "7");
                        ////capability.SetCapability("browser", "IE");
                        ////capability.SetCapability("browser_version", "8.0");
                        ////capability.SetCapability("resolution", "1024x768");
                        ////iphone
                        //capability.SetCapability("browserName", "iPhone");
                        //capability.SetCapability("device", "iPhone 7");
                        //capability.SetCapability("realMobile", "true");
                        //capability.SetCapability("os_version", "10.3");
                        ////capability.SetCapability("browser", "IE");
                        //capability.SetCapability("browser_version", "8.0");
                        //capability.SetCapability("resolution", "1024x768");
                        //capability.SetCapability("browserstack.local", "true");
                        //capability.SetCapability("video", "True");
                        //user agent
                        //_currentWebDriver = new RemoteWebDriver(new Uri("http://hub-cloud.browserstack.com/wd/hub/"), capability);
                        break;
                    case "AndroidS8":
                        //DesiredCapabilities capabilitys8 = DesiredCapabilities.Chrome();
                        //browserStackLocal = new Local();
                        ////                  List<KeyValuePair<string, string>> bsLocalArgs = new List<KeyValuePair<string, string>>() {
                        ////  new KeyValuePair<string, string>("key", "ks4EQsKUm9pj1Z334RsZ")
                        ////};
                        //if (capabilitys8.GetCapability("browserstack.local") != null && capabilitys8.GetCapability("browserstack.local").ToString() == "true")
                        //{
                        //    browserStackLocal = new Local();
                        //    List<KeyValuePair<string, string>> bsLocalArgs = new List<KeyValuePair<string, string>>() {
                        //            new KeyValuePair<string, string>("key", "o2R5cBxcqazByzJjtp32")
                        //            };
                        //    browserStackLocal.start(bsLocalArgs);
                        //}
                        //capabilitys8.SetCapability("browserName", "android");
                        //capabilitys8.SetCapability("device", "Samsung Galaxy S8");
                        //capabilitys8.SetCapability("realMobile", "true");
                        //capabilitys8.SetCapability("os_version", "7.0");
                        //capabilitys8.SetCapability("browserstack.user", "softura1");
                        //capabilitys8.SetCapability("browserstack.key", "o2R5cBxcqazByzJjtp32");
                        //_currentWebDriver = new RemoteWebDriver(new Uri("http://hub-cloud.browserstack.com/wd/hub/"), capabilitys8);

                        break;
                    case "phantomjsdriver":
                        //_currentWebDriver = new PhantomJSDriver(BrowserDriverPath + "PhantomJSDriver");
                        break;
                    default:
                        throw new NotSupportedException($"{BrowserConfig} is not a supported browser");
                }

                return _currentWebDriver;

            }

        }

        private WebDriverWait _wait;
        public WebDriverWait Wait
        {
            get
            {
                if (_wait == null)
                {
                    this._wait = new WebDriverWait(Current, TimeSpan.FromSeconds(10));
                }
                return _wait;
            }
        }

        protected string BrowserConfig => ConfigurationManager.AppSettings["browser"];

        protected string SeleniumBaseUrl => ConfigurationManager.AppSettings["seleniumBaseUrl"];

        public void Quit()
        {
            _currentWebDriver?.Quit();
        }

    }
}
