﻿#error Could not find a reference to SpecFlow in project 'DemoAutomation'.
#error Please add the 'TechTalk.SpecFlow' package to the project and use MSBuild generation instead of using SpecFlowSingleFileGenerator.
#error For more information see https://specflow.org/documentation/Generate-Tests-from-MsBuild/